create_not_post =\
    ("<p><a href='/'>INÍCIO</a></p><p>Nenhuma inserção foi"
     "solicitada. Volte ao início da interface.</p>")

create_existant_user =\
    ("ERRO: usuário já existente. Você pode VOLTAR e "
     "tentar atualizar a tabela.")

create_success =\
    ("Inserção feita com SUCESSO. Realize outra inserção ou faça uma"
     "consulta para conferir.")

create_html_path = "interface/create.html"

usuario = "Usuario"

