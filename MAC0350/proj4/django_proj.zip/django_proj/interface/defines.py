create_not_post =\
    ("<p><a href='/'>INÍCIO</a></p><p>Nenhuma inserção foi "
     "solicitada. Volte ao início da interface.</p>")

delete_not_post =\
    ("<p><a href='/'>INÍCIO</a></p><p>Nenhuma eliminação foi "
     "solicitada. Volte ao início da interface.</p>")

query_not_post =\
    ("<p><a href='/'>INÍCIO</a></p><p>Nenhuma consulta foi "
     "solicitada. Volte ao início da interface.</p>")

error_existant_user =\
    ("ERRO: usuário já existente. Você pode VOLTAR e "
     "tentar atualizar a tabela.")

error_nonexistant_person = "ERRO: pessoa não existente."
error_nonexistant_exam =\
    ("ERRO: exame não existe. Você pode VOLTAR e tentar "
     "inseri-lo na tabela.")

create_success =\
    ("Inserção feita com SUCESSO. Realize outra inserção ou faça uma "
     "consulta para conferir.")

delete_success = ("Eliminação feita com SUCESSO. Confira abaixo.")

create_html = "interface/create.html"
delete_html = "interface/delete.html"
update_html = "interface/update.html"
index_html = "interface/index.html"

select_all_usuario = "SELECT * FROM usuario"
select_all_pessoa = "SELECT * FROM pessoa"
select_all_exam = "SELECT * FROM exame"
select_all_service = "SELECT * FROM servico"
select_all_profile = "SELECT * FROM perfil"

table_usuario = "Usuario"
table_profile = "Perfil"
table_service = "Servico"

status_select = "select"
